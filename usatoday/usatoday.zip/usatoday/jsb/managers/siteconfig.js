
define('managers/siteconfig',[
    'underscore',
    'pubsub',
    'utils',
    'mergedSiteConfig'
], function(_, PubSub, Utils, mergedSiteConfig) {
    'use strict';
    /**
     * SiteConfig Loading Helper Manager that will load and merge a number of site configs into one site config
     * @exports managers/siteconfig
     * @author Jay Merrifield <jmerrifiel@gannett.com>
     */
    var SiteConfig = {
        /**
         * Given a list of site configs, will return a merged copy
         * @param {Array.<Object>} siteConfigList list of site configs to load and merge
         * @returns {Object} merged site config
         */
        inited: false,
        getSiteConfig: function() {
            if (!this.inited) {
                this.inited = true;
                this.setupSiteConfig(mergedSiteConfig);
            }
            return mergedSiteConfig;
        },

        setupSiteConfig: function(siteConfig) {
            if (siteConfig.require && (!_.isEmpty(siteConfig.require.paths) || !_.isEmpty(siteConfig.require.shim))) {
                require.config(siteConfig.require);
            }
            SiteConfig._replaceEnvVariables(siteConfig);
            this._setupGlobalPubSub(Utils.getNested(siteConfig, 'global', 'pubSub'));
        },

        _setupGlobalPubSub: function(pubSubMap) {
            _.each(pubSubMap, function(paths, key) {
                if (!(paths instanceof Array)){
                    paths = [paths];
                }
                require(paths, _.bind(function() {
                    var mods = arguments;
                    PubSub.on(key, function(options) {
                        _.each(mods, function(Mod) {
                            new Mod(options);
                        });
                    });
                }, this));
            }, this);
        },

        _replaceEnvVariables: function(siteConfig){
            // environment variables only are allowed in page urls at the moment
            _.each(siteConfig.pages, function(page){
                if (page.urls) {
                    var pageUrls = [];
                    _.each(page.urls, function(url){
                        if (url.indexOf('<%') != -1 && url.indexOf('%>') != -1) {
                            try{
                                url = _.template(url, {});
                            } catch(e) {
                                console.error("invalid url template: " + url);
                                url = undefined;
                            }
                        }
                        if (url !== undefined) {
                            pageUrls.push(url);
                        }
                    });
                    page.urls = pageUrls;
                }
            });
        }
    };
    return SiteConfig;
});