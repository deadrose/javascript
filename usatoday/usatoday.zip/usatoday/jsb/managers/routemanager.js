
define('managers/routemanager',['jquery', 'underscore', 'backbone'],
    function($, _, Backbone) {

        var RouteManager = Backbone.Router.extend({
            initialize: function(options){
                this.options = $.extend(true, {
                    appMap: {},
                    pageList: [],
                    onRouteChange: function(app, route, path){}
                }, options);
                this.urls = [];
                this._preloadRoutes(this.options.pageList, this.options.appMap);
            },
            destroy: function(){
                Backbone.history.stop();
            },
            getRouteInfoForUrl: function(path){
                return _.find(this.urls, function(url){
                    return url.url.test(path);
                });
            },
            _preloadRoutes: function(pageList, appMap) {
                var numAppsLoading = _.size(appMap);
                var _this = this;
                // we preload all apps so we can load them quickly, pages are lazy
                _.each(appMap, function(app) {
                    require([app.path], function(AppClass) {
                        app.AppClass = AppClass;
                        numAppsLoading--;
                        if (!numAppsLoading) {
                            // now that we have all the apps, register the routes and start the history
                            _this._loadBackboneRoute(pageList, appMap);
                        }
                    });
                });
            },
            _loadBackboneRoute: function(pageList, appMap){
                // backbone matches last to first to allow for new routes to overwrite old routes,
                // but we're loading siteconfigs in python order which is first match, so we reverse the list
                // to get the right order
                var _this = this;
                pageList.reverse();
                _.each(pageList, function(page) {
                    var app = appMap[page.appName] || 'BaseApp';
                    if (!app) {
                        console.error('Invalid appName for Page ' + page.name);
                    } else {
                        page.modules = (page.init_modules || []).concat(app.init_modules || []);
                        var urls = (page.hosturls && page.hosturls[location.hostname]) || page.urls;
                        _.each(urls, function(url) {
                            var regEx = new RegExp(url),
                                routeInfo = {url: regEx, app: app, page: page};
                            // later urls are matched first to match backbone's route matcher
                            _this.urls.unshift(routeInfo);
                            _this.route(regEx, app.name, function onRouteChange() {
                                _this.options.onRouteChange(routeInfo, Backbone.history.getFragment(window.location.pathname + window.location.search));
                            });
                        });
                    }
                });

                // Special route to handle Facebook Connect #_=_ mess.  Won't be necessary after Backbone 1.1.0.
                // See https://developers.facebook.com/blog/post/552/ under "Change in Session Redirect Behavior".
                _this.route('_=_', 'facebook-connect-login-fragment', function() {
                        // keep the path, modulo the preceeding slash and the stuff we're trying to remove
                        var fixedpath = window.location.pathname.replace(/^\//, '').replace(/_=_$/, '');

                        // Remove it from the URL while we're at it.
                        _this.navigate(fixedpath + window.location.search, {trigger: true, replace: true});
                    });

                Backbone.history.start({pushState: true, hashChange: false});
                console.log("Site Loaded");
            }
        });
        return RouteManager;
    }
);
