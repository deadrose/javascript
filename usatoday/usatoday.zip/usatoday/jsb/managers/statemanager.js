
define('state',[
    'jquery',
    'underscore',
    'pubsub',
    'utils',
    'modules/global/alert',
    'managers/trafficcop',
    'managers/requestmanager',
    'managers/routemanager',
    'managers/resourcemanager',
    'site-manager',
    'managers/siteconfig'
],
function(
    $,
    _,
    PubSub,
    Utils,
    Alert,
    TrafficCop,
    RequestManager,
    RouteManager,
    ResourceManager,
    SiteManager,
    SiteConfig
) {
    'use strict';
    if (!Object.getPrototypeOf) {
        // polyfill for IE8 (fullscreen transitions need it)
        Object.getPrototypeOf = function(object){
            // May break if the constructor has been tampered with
            return object.constructor.prototype;
        };
    }
    /**
     * @event page:unload
     * @desc This event is fired when a page is torn down before all animation and ajax requests are fired
     */
    /**
     * State Manager that handles the application state. Maintains the active view and
     * manages routing and transitioning between the views. Ajax calls and animation calls
     * should be registered with the state manager to guarantee that animation isn't interrupted
     * and that stale or requests that are being thrown out.
     * @requires managers/trafficcop
     * @requires managers/requestmanager
     * @exports state
     * @author Jay Merrifield <jmerrifiel@gannett.com>
     */
    var StateManager = function(){
        this.scrollEl = Utils.get('scrollEl');
        this.body = Utils.get('body');
        this.initialize();
    };
    StateManager.prototype = {
            /** @const
             * @private */
            DEBUG: true,
            /** @const
             * @private */
            LAYER_OVERLAY: 'overlay',
            /** @const
             * @private */
            LAYER_PRELOAD: 'preload',
            /** @const
             * @private */
            LAYER_BASE: 'base',
            /** @const
             * @private */
            REFRESH_FREQUENCY: (window.site_config.REFRESH_RATE || 0) * 60 * 1000,

            /**
             * This starts state manager, spin up the route manager, resource manager, and refresh timer
             */
            start: function() {
                var siteConfig = SiteConfig.getSiteConfig(); // stash this so we can debug it's value
                this.siteConfig = siteConfig;
                this.started = true;
                this.routeManager = new RouteManager({
                    appMap: siteConfig.apps,
                    pageList: siteConfig.pages,
                    onRouteChange: _.bind(this._onRouteChange, this)
                });

                this.resourceManager = new ResourceManager({
                    siteModules: siteConfig.siteModules
                });

                // If click is not registered for 15 min, refresh the page --
                // for non-overlays.
                this.startRefreshTimer();
            },

            stop: function(){
                this.started = false;
                _.each(Utils.getNested(this.siteConfig, 'global', 'pubSub'), function(paths, key) {
                    PubSub.off(key);
                });
            },

            fetchPageModules: function(pageModules) {
                return this.resourceManager.fetchPageModules(pageModules);
            },
            /**
             * Internal initialization helper, builds activeAppInfo and preloadedAppInfo objects
             */
            initialize: function() {
                this.$overlayFilm = $('#overlay-film');
                this.activeAppInfo = {
                    url: null,
                    css: [],
                    layer: null,
                    scrollTop: 0,
                    app: null
                };
                this.lastUrl = null;
                this._clearPreloadedAppInfo();
                this.fullscreenView = null;
            },
            _clearPreloadedAppInfo: function() {
                this.preloadedAppInfo = {
                    url: null,
                    css: [],
                    scrollTop: 0,
                    layer: this.LAYER_PRELOAD,
                    app: null
                };
            },

            /**
             * Route Change callback for route manager, will make certain the correct app, route, and path
             * are loaded properly into state manager
             * @param {Object} routeInfo - object representing the app and page that owns the path, including what class needs to be initialized
             * @param {String} url that is being loaded
             * @private
             */
            _onRouteChange: function(routeInfo, url) {
                console.log('App: ' + routeInfo.page.appName + '/' + routeInfo.page.name);
                var appInitOptions = {
                    preloadedUrl: routeInfo.page.preloadedUrl || routeInfo.app.preloadedUrl
                };
                return this._loadApp(routeInfo.app.AppClass, appInitOptions, url, routeInfo.app.overlay, routeInfo.page);
            },

            /**
             * Will load the given path into a preloaded/stashed state that can be quickly navigated to when asked
             * can only be used if the active app is an overlay
             * (but if we do not own that path, just ignore it until we close out of the current content)
             * @param {String} fragment to preload
             * @return {Deferred} promise object that resolves when the path is fully loaded
             */
            preloadPath: function(fragment) {
                var routeInfo, url = Utils.getDefinedRoute(fragment);
                if (url || url === '') {
                    routeInfo = this.routeManager.getRouteInfoForUrl(url);
                    if (!window.chromeless && routeInfo && (!this.activeAppInfo.layer || this.activeAppInfo.layer === this.LAYER_OVERLAY)) {
                        return this._preloadApp(routeInfo.app.AppClass, {}, url, routeInfo.page);
                    } else {
                        return $.Deferred().reject();
                    }
                } else {
                    /* fake preload: do not preload anything, but tell .navigateToPreloadedUrl() where to go */
                    return $.Deferred().reject();
                }
            },

            /**
             * Given a path, determine it's layer, resources, and how to transition to it correctly
             * @param {String} url to navigate to
             * @return {Deferred} promise object
             * @private
             */
            _loadPath: function(url) {
                var routeInfo = this.routeManager.getRouteInfoForUrl(url);
                if (!routeInfo) {
                    console.error('StateManager: tried navigating to path, but no match found: ' + url);
                    return null;
                } else {
                    return this._onRouteChange(routeInfo, url);
                }
            },

            /**
             * Triggers an ajax reload of the current page
             * @returns {Deferred}
             */
            refreshActiveApp: function() {
                var currentPath = this.activeAppInfo.url,
                    pageInfo = this.routeManager.getRouteInfoForUrl(currentPath).page,
                    resourcePromise = this.resourceManager.fetchJavascript(pageInfo.buildfile && pageInfo.buildfile.path, pageInfo.path, pageInfo.modules),
                    requestPromise = this._fetchPathHtml(currentPath);

                PubSub.trigger('page:unload');
                return this.activeAppInfo.app.changePage(currentPath, currentPath, requestPromise, resourcePromise);
            },

            /**
             * This is used when we want to pretend like we navigated to the url, but don't make the request yet.
             * This is to facility inbetween ads that want to interrupt and redirect a page navigation to an ad instead.
             * The goal is that if the user hits reload, they get the page they were intending to go to. If they hit the
             * back button they go back to the url they were at.
             * @param {String} url
             * @returns {Boolean} whether or not the ajax navigate succeeded. It doesn't succeed if the url isn't
             */
            partialNavigateToUrl: function(url){
                if (Utils.triggerRoute(url, null, null, true)) {
                    this.activeAppInfo.intentUrl = Utils.getDefinedRoute(url);
                    return true;
                }
                return false;
            },

            /**
             * Navigates to the current preloaded url, or the default path passed in if no preloaded app is currently there
             * @param defaultPath
             */
            navigateToPreloadedUrl: function(defaultPath) {
                var navPath = this.preloadedAppInfo.url || defaultPath;
                if (!navPath) {
                    navPath = '/';
                } else if (navPath[0] !== '/') {
                    if (!navPath.match(/^https?:/)) {
                        navPath = '/' + navPath;
                    }
                }
                var navWarning = this.getActivePageInfo().navigationWarning;
                if (navWarning && !window.confirm(navWarning)) {
                    return;
                }
                Utils.triggerRoute(navPath);
            },

            /**
             * Registers a full screen view with the state manager. This is necessary because
             * the full screen view doesn't have a unique url and lives outside the knowledge
             * of the state manager
             * @param {Object} fullscreenView
             */
            registerFullScreenView: function(fullscreenView) {
                this._setFixedPosition(this.activeAppInfo, this.activeAppInfo.app, true);
                this.fullscreenView = fullscreenView;
                // pause the app, and all it's modules
                this.activeAppInfo.app.pause();
            },

            setActiveAppFixed: function(partialCover) {
                this._setFixedPosition(this.activeAppInfo, this.activeAppInfo.app, partialCover);
            },

            /**
             * Clears out the full screen view from the state manager
             */
            clearFullScreenView: function() {
                this._clearFixedPosition(this.activeAppInfo, this.activeAppInfo.app, true);
                // fullscreenView will be null if state manager triggered the close, which means
                // the user triggered a transition somewhere else, so don't rebuild the current view
                if (this.fullscreenView) {
                    this.fullscreenView = null;
                    // trigger a transition in place, with no requestPromise to fire beforePageReveal and afterPageReveal
                    // and restore all javascript
                    return this._loadPath(this.activeAppInfo.url);
                }
            },

            clearActiveAppFixed: function(partialCover) {
                this._clearFixedPosition(this.activeAppInfo, this.activeAppInfo.app, partialCover);
            },


            /**
             * This is the main state manager call, this will compare what the current state
             * of the universe is, and make any ajax calls, and transition to the current state
             * with the correct view information
             *
             * @param {Function} NextAppClass the javascript class that is taking over the site.
             * @param {Object} initOptions any initialization options for the view class.
             * @param {String} toUrl path being loaded.
             * @param {Boolean} overlay overlay the view on top of the existing view.
             * @param {Object} pageInfo page info for the path
             */
            _loadApp: function(NextAppClass, initOptions, toUrl, overlay, pageInfo) {
                var finishPromise, type = (overlay ? this.LAYER_OVERLAY : this.LAYER_BASE),
                    resourcePromise = this.resourceManager.fetchJavascript(pageInfo.buildfile && pageInfo.buildfile.path, pageInfo.path, pageInfo.modules);

                this._closeFullscreenView();

                // Save the active url before we transition which could tamper with the url
                this.lastUrl = this.activeAppInfo.url;
                if (this.activeAppInfo.app) {
                    PubSub.trigger('page:unload');
                    if (this.activeAppInfo.intentUrl && this.activeAppInfo.intentUrl !== toUrl) {
                        // pretend as if we're coming from the intentUrl instead of the actual current url
                        this.activeAppInfo.url = this.activeAppInfo.intentUrl;
                    }
                    this.activeAppInfo.intentUrl = null;
                }
                finishPromise = this._handleTransition(toUrl, this.activeAppInfo, NextAppClass, initOptions, type, resourcePromise);
                this.activeAppInfo.css = pageInfo.css || [];
                this.activeAppInfo.url = toUrl;
                this.activeAppInfo.layer = type;
                this.resourceManager.fetchStyles(_.union(this.preloadedAppInfo.css, this.activeAppInfo.css), finishPromise);
                return finishPromise;
            },
            /**
             * preloads an app
             * @param {Function} NextAppClass
             * @param {Object} initOptions
             * @param {String} toUrl
             * @param {Object} pageInfo
             * @returns {Deferred}
             * @private
             */
            _preloadApp: function(NextAppClass, initOptions, toUrl, pageInfo) {
                if (this.DEBUG) {
                    console.log('Router: Preloading: ', toUrl);
                }
                var finishPromise = this._handleTransition(toUrl, this.preloadedAppInfo, NextAppClass, initOptions,
                                                           this.LAYER_PRELOAD, $.Deferred().resolve());
                this.preloadedAppInfo.css = pageInfo.css || [];
                this.preloadedAppInfo.url = toUrl;
                this.resourceManager.fetchStyles(_.union(this.preloadedAppInfo.css, this.activeAppInfo.css), finishPromise);
                return finishPromise;
            },
            _closeFullscreenView: function(){
                // full screen views live outside of the state manager because they don't
                // modify the url. If that assumption ever changes, we should switch
                // full screen view to being state managed and this hack can go away
                if (this.fullscreenView) {
                    // we need to clear out fullscreenView before calling close,
                    // because we are navigating to a new view, and don't want an accidental
                    // call to clearFullscreenView to reinstantiate the activeView
                    var fullscreenView = this.fullscreenView;
                    this.fullscreenView = null;
                    fullscreenView.close();
                }
            },
            /**
             * Handle transitions from fromUrl to toUrl
             * @param {String} toUrl - url we're going to
             * @param {Function} NextAppClass - function for generating the next app
             * @param {Object} initOptions - options for the new app
             * @param {String} requestedLayerType - type of layer the new app is
             * @param {Deferred} resourcePromise - promise that resolves when all the js resources are loaded
             * @returns {Deferred} promise that will resolve when the transition finishes
             * @private
             */
            _handleTransition: function(toUrl, layerObj, NextAppClass, initOptions, requestedLayerType, resourcePromise) {
                var requestedApp,
                    fromUrl = layerObj.url,
                    preload = requestedLayerType === this.LAYER_PRELOAD,
                    requestPromise = null;
                if (this._needsNewApp(NextAppClass, layerObj)) {
                    requestedApp = new NextAppClass(initOptions); // construct a new app, so we can talk to it
                    requestPromise = this._requestPageHtml(fromUrl, toUrl, preload); // request html (optional)
                    // Scenarios
                    if (!layerObj.app) {
                        // 1: First time page load or first time preload (just reveal app)
                        return this._revealApp(layerObj, requestedApp, fromUrl, toUrl, requestPromise, resourcePromise, preload);
                    } else {
                        if (layerObj.layer === requestedLayerType) {
                            // 2: change from layer -> same layer, but different app (remove current app, reveal new app)
                            return layerObj.app.removeApp(fromUrl, toUrl).then(_.bind(function(){
                                return this._revealApp(layerObj, requestedApp, fromUrl, toUrl, requestPromise, resourcePromise, preload);
                            }, this));
                        } else if (requestedLayerType === this.LAYER_OVERLAY) {
                            // 3: Opening overlay on top of app (stash current app, reveal new app)
                            return this._revealOverlay(requestedApp, fromUrl, toUrl, requestPromise, resourcePromise);
                        } else {
                            // overlay to base layer, remove preloaded app if necessary and reveal new app
                            return $.when(this._removePreloadedApp(fromUrl, toUrl), this._removeOverlay(layerObj.app, fromUrl, toUrl)).then(_.bind(function() {
                                return this._revealApp(layerObj, requestedApp, fromUrl, toUrl, requestPromise, resourcePromise, preload);
                            }, this));
                        }
                    }
                } else {
                    // no new app scenarios:
                    if (layerObj.layer === requestedLayerType) {
                        // 1: changePage of current app
                        requestPromise = this._requestPageHtml(fromUrl, toUrl, preload);
                        return layerObj.app.changePage(fromUrl, toUrl, requestPromise, resourcePromise, preload);
                    } else {
                        // 2: remove overlay and show preloaded app
                        return this._transitionFromOverlayToPreloadedApp(fromUrl, toUrl, resourcePromise);
                    }
                }
            },

            /**
             * Given the preloaded app, will remove it from the internal data structure as well as the dom
             * @param {String} fromUrl - url we're coming from
             * @param {String} toUrl - url we're going to
             * @returns {Deferred|undefined}
             * @private
             */
            _removePreloadedApp: function(fromUrl, toUrl) {
                var preloadedApp = this.preloadedAppInfo.app;
                if (preloadedApp) {
                    this._clearPreloadedAppInfo();
                    preloadedApp.beforeOverlayRemove(toUrl);
                    return preloadedApp.removeApp(fromUrl, toUrl);
                }
            },

            /**
             * triggers revealApp on the requestedApp, sets the app as active on the layer
             * @param {Object} layerObj
             * @param {Object} requestedApp
             * @param {String} fromUrl
             * @param {String} toUrl
             * @param {Deferred} requestPromise
             * @param {Deferred} resourcePromise
             * @param {Boolean} preload
             * @returns {Deferred}
             * @private
             */
            _revealApp: function(layerObj, requestedApp, fromUrl, toUrl, requestPromise, resourcePromise, preload) {
                layerObj.app = requestedApp;
                return requestedApp.revealApp(fromUrl, toUrl, requestPromise, resourcePromise, preload);
            },

            /**
             * Returns whether or not we need a new app to handle the current url request
             * @param {Function} NextAppClass
             * @param {Object} layerObj
             * @returns {Boolean}
             * @private
             */
            _needsNewApp: function(NextAppClass, layerObj) {
                return !layerObj.app || // no app yet, ie first page load or first preload load
                    !layerObj.app.isRevealed() || // app isn't ready yet
                    // the new app doesn't match the active app, opening overlay, closing overlay, changing app at current level
                    (Object.getPrototypeOf(layerObj.app) !== NextAppClass.prototype &&
                        // we do need a new app unless there's a preloaded app and the preloaded app matches the requested app (close overlay to preloaded app)
                        (!this.preloadedAppInfo.app || Object.getPrototypeOf(this.preloadedAppInfo.app) !== NextAppClass.prototype));
            },
            /**
             * Requests the next page's html, or, if it's not needed, will abort all non-nav requests because the current page is being destroyed
             * @param {String} fromUrl - url we're coming from
             * @param {String} toUrl - url we're going to
             * @param {Boolean} preload - whether this fetch is for a preloaded app or an active app, controls whether we need to abort the ajax
             * @returns {Deferred|null}
             * @private
             */
            _requestPageHtml: function(fromUrl, toUrl, preload) {
                if (fromUrl !== null || preload) {
                    if (fromUrl !== toUrl) {
                        return this._fetchPathHtml(toUrl, preload);
                    } else if (!preload) {
                        // without this, background requests would still fire because we didn't trigger a nav request
                        RequestManager.abortAllRequests();
                    }
                }
                return null;
            },
            /**
             * Transitions from the overlay layer to the preloaded layer, assumes that _removeApps has been called
             * and will pass in a valid removalPromise
             * @param {String} fromUrl - url we're coming from
             * @param {String} toUrl - url we're going to
             * @param {Deferred} resourcePromise - promise that resolves when all the js resources are loaded
             * @returns {Deferred} promise that resolves when the entire transition is complete
             * @private
             */
            _transitionFromOverlayToPreloadedApp: function(fromUrl, toUrl, resourcePromise) {
                var nextAppInfo = this.preloadedAppInfo,
                    requestPromise = this._requestPageHtml(nextAppInfo.url, toUrl, false),
                    currentApp = this.activeAppInfo.app;
                this._movePreloadAppToActiveApp(this.LAYER_BASE);
                nextAppInfo.app.beforeOverlayRemove(toUrl);
                return this._removeOverlay(currentApp, fromUrl, toUrl).then(_.bind(function() {
                    // transition the active app to optionally trigger an animation and init it
                    this._transitionFromOverlayScroll(nextAppInfo);
                    return nextAppInfo.app.changePage(fromUrl, toUrl, requestPromise, resourcePromise, false);
                }, this));
            },

            /**
             * Removes the passed in overlay app and it's overlay
             * @param {Object} overlayApp
             * @param {String} fromUrl - url we're coming from
             * @param {String} toUrl - url we're going to
             * @returns {Deferred}
             * @private
             */
            _removeOverlay: function(overlayApp, fromUrl, toUrl) {
                return $.when(overlayApp.removeApp(fromUrl, toUrl), this._fadeOutOverlayFilm(overlayApp));
            },

            /**
             * Takes the preloaded app, and copies it to the active app structure
             * @param requestedLayer
             * @private
             */
            _movePreloadAppToActiveApp: function(requestedLayer) {
                this.activeAppInfo.app = this.preloadedAppInfo.app;
                this.activeAppInfo.css = this.preloadedAppInfo.css;
                this.activeAppInfo.url = this.preloadedAppInfo.url;
                this.activeAppInfo.layer = requestedLayer;
                this._clearPreloadedAppInfo();
            },
            /**
             * Takes the current app, and puts it into the preloadedApp data structure
             * @private
             */
            _deactivateActiveApp: function() {
                this.activeAppInfo.app.pause();
                this.preloadedAppInfo.app = this.activeAppInfo.app;
                this.preloadedAppInfo.url = this.activeAppInfo.url;
                this.preloadedAppInfo.css = this.activeAppInfo.css || [];
            },
            _revealOverlay: function(nextApp, fromUrl, toUrl, requestPromise, resourcePromise) {
                // save the transitionView, cause the world might change by the time we finish animating
                var appToBeStashed = this.activeAppInfo.app;
                if (!appToBeStashed.isRevealed()) {
                    appToBeStashed.removeApp(fromUrl, toUrl);
                    appToBeStashed = null; // skip it, it's not in a valid state
                } else {
                    this._deactivateActiveApp();
                }
                this.body.css('overflow-y', 'scroll');
                this._transitionToOverlayScroll(this.preloadedAppInfo);
                var promise = $.when(this._fadeInOverlayFilm(nextApp), this._revealApp(this.activeAppInfo, nextApp, fromUrl, toUrl, requestPromise, resourcePromise, false));
                SiteManager.scrollTop(0);
                promise.done(_.bind(function() {
                    this.body.css('overflow-y', '');
                    if (appToBeStashed) {
                        appToBeStashed.afterOverlayReveal(this.scrollTop);
                    }
                }, this));
                return promise;
            },
            /**
             * Fades in the overlay film, adds one to the dom if necessary
             * @param {Object} nextApp
             * @returns {Deferred}
             * @private
             */
            _fadeInOverlayFilm: function(nextApp) {
                var fadeInOptions = nextApp.options.animations.fadeIn;
                if (!this.$overlayFilm.length) {
                    this.$overlayFilm = $('<div class="ui-film"></div>');
                    this.body.append(this.$overlayFilm);
                }
                return nextApp.animate(this.$overlayFilm, 'opacity', 0.7, fadeInOptions.duration, 'ease-in');
            },
            /**
             * Fades out the overlay film, removes it from the dom
             * @param {Object} activeApp
             * @returns {Deferred}
             * @private
             */
            _fadeOutOverlayFilm: function(activeApp) {
                var overlayFilm = this.$overlayFilm,
                    fadeOutOptions = activeApp.options.animations.fadeOut;
                this.$overlayFilm = $([]);
                return activeApp.animate(overlayFilm, 'opacity', 0, fadeOutOptions.duration, 'ease-out').done(function(){
                    overlayFilm.remove();
                });
            },
            _fetchPathHtml: function(toUrl, preload) {
                var requestPromise = this.fetchHtml(toUrl, null, !preload);
                if (!preload) {
                    requestPromise.fail(_.bind(function(e) {
                        if (e) {
                            if (e === 'NOT AUTHORIZED') {
                                this._loadPath(Utils.getNested(window, 'firefly_urls', 'samSubscribeURL') || '');
                            } else {
                                var msg = this.generateRequestError(e);
                                if (msg) {
                                    Alert.showError(msg);
                                }
                                if ((e.status !== 200 && e.status) || e.statusText === 'timeout') {
                                    // if the status is 200, means the request succeeded, but the promise was rejected/aborted
                                    // status of 0 means the connection itself was aborted
                                    window.history.back();
                                }
                            }
                        }
                    }, this));
                }
                return requestPromise;
            },
            generateRequestError: function(e) {
                if (e) {
                    if (e.status === 500) {
                        return 'Connection Error... (INTERNAL SERVER ERROR)';
                    } else if (e.status === 404) {
                        return 'Connection Error... (FILE NOT FOUND)';
                    } else if (e.status !== 200 && e.status) {
                        // if the status is 200, we just got canceled, otherwise we show some error message
                        return 'Connection Error... (' + (e.statusText || 'Unknown Error') + ')';
                    }
                }
                return null;
            },
            _transitionFromOverlayScroll: function(appInfo) {
                var app = appInfo.app;
                if (app) {
                    if (app.isApple) {
                        // fixed position and scrolltop don't get along
                        app.show();
                    } else {
                        this._clearFixedPosition(appInfo, app);
                    }
                    // reset z-index
                    app.$el.css('z-index', '');
                }
            },
            _transitionToOverlayScroll: function(appInfo) {
                var app = appInfo.app;
                if (app) {
                    if (app.isApple) {
                        // fixed position and scrolltop don't get along
                        app.hide();
                    } else {
                        this._setFixedPosition(appInfo, app);
                    }
                    // force the active app to sit below the overlay
                    app.$el.css('z-index', '0');
                }
            },
            _clearFixedPosition: function(appInfo, app, partialCover) {
                app.clearFixedPosition(partialCover);
                SiteManager.scrollTop(appInfo.scrollTop || 0);
            },
            _setFixedPosition: function(appInfo, app, partialCover) {
                var appPosition = app.getWindowOffset().top;
                appInfo.scrollTop = Utils.getScrollPosition();
                SiteManager.scrollTop(0);
                app.setFixedPosition(appPosition, partialCover);
            },

            /**
             * Store the timestamp of the latest activity (ie. mousemove). Used
             * to determine whether to refresh browser automatically after a
             * certain period of idle time.
             */
            updateActivityTimestamp: function() {
                this.lastActivityTimestamp = (new Date()).getTime();
            },

            /**
             * Gets the active page info object
             * @returns {PageInfo}
             */
            getActivePageInfo: function(){
                var activeApp = this.getActiveApp() || {};
                return activeApp.pageInfo || {};
            },
            /**
             * Gets the preloaded page info object
             * @returns {PageInfo}
             */
            getPreloadedPageInfo: function(){
                return this.preloadedAppInfo.app && this.preloadedAppInfo.app.pageInfo || {};
            },
            /**
             * Gets the current active app
             * @returns {Object}
             */
            getActiveApp: function(){
                return this.activeAppInfo.app;
            },
            /**
             * Gets the preloaded app if one exists
             * @returns {Object}
             */
            getPreloadedApp: function(){
                return this.preloadedAppInfo.app;
            },

            /**
             * Retrieves the last url the site ajax'd from
             * @returns {String}
             */
            getLastUrl: function(){
                return this.lastUrl;
            },

            /**
             * Start refresh interval. Check current time against last activity
             * and refresh the page if it's been longer than threshold of idle
             * time.
             */
            startRefreshTimer: function() {
                if (!this.refreshTimer && this.REFRESH_FREQUENCY) {
                    this.lastActivityTimestamp = 0;
                    this.refreshTimer = setInterval(_.bind(function(){
                        if (!this.fullscreenView && this.activeAppInfo.layer !== this.LAYER_OVERLAY) {
                            var currentTime = (new Date()).getTime();
                            var idleTime = currentTime - this.lastActivityTimestamp;
                            if (idleTime > this.REFRESH_FREQUENCY) {
                                PubSub.trigger('site:refresh', 'refresh:' + (this.getActivePageInfo().ssts || '').replace(/[\/:].*/, ''));
                                window.location = window.location;
                            }
                        }
                    }, this), this.REFRESH_FREQUENCY);
                }
            },

            /**
             * Stop refresh timer.
             */
            stopRefreshTimer: function() {
                if (this.refreshTimer) {
                    clearInterval(this.refreshTimer);
                    this.refreshTimer = null;
                }
            },

            /**
             * Registers a navigation animation that should defer all incoming ajax requests
             * @param {Deferred} deferred jQuery promise object
             * @param {jQuery} [el] dom element
             * @param {String} [property] name
             * @param {String|Number} [value] being animated to
             * @param {Number} [timeMs] time for animation
             * @return {Deferred} representing when all animations are done
             */
            registerAnimation: function(deferred, el, property, value, timeMs) {
                return TrafficCop.addAnimation(deferred, el, property, value, timeMs);
            },

            /**
             * Helper function that auto populates fetchData with the isHtml flag being true
             * @param {String} path The path to the ajax endpoint.
             * @param {Object} [options] jQuery ajax option.
             * @param {Boolean} [isNavigation] specifies if this request is a navigation request
             *                  or a background loading request.
             * @param {Boolean} [isStatic] tells the ajax request whether to add
             *      the pjax headers or not
             * @return {Deferred} jQuery promise object
             */
            fetchHtml: function(path, options, isNavigation, isStatic) {
                return RequestManager.fetchHtml(path, options, isNavigation, isStatic, true);
            },

            /**
             * Fetch data from server via AJAX. Takes a path to fetch and a
             * callback to parse the data and initialize views.
             * @param {String} path The path to the ajax endpoint.
             * @param {Object} [options] jQuery ajax option.
             * @param {Boolean} [isNavigation] specifies if this request is a navigation request
             *                  or a background loading request.
             * @param {Boolean} [isStatic] tells the ajax request whether to add
             *      the pjax headers or not
             * @param {Boolean} [isHtml] will return a quickly built jQuery dom object.
             * @return {Deferred} jQuery promise object
             */
            fetchData: function(path, options, isNavigation, isStatic, isHtml) {
                return RequestManager.fetchData(path, options, isNavigation, isStatic, isHtml);
            },

            /**
             * repeatedly calls fetchHtml at a specified interval and passing the results to a callback
             * @param {String} path The path to the ajax endpoint.
             * @param {Object} options ajax options
             * @param {Number} interval time in ms to repeat
             * @param {Function} callback function to call when fetchHtml succeeds
             * @param {Boolean} [isStatic] tells the ajax request whether to add the pjax headers or not
             * @return {Number} setInterval id
             */
            recurringFetchHtml: function(path, options, interval, callback, isStatic){
                return RequestManager.recurringFetchHtml(path, options, interval, callback, isStatic, true);
            },

            /**
             * repeatedly calls fetchData at a specified interval and passing the results to a callback
             * @param {String} path The path to the ajax endpoint.
             * @param {Object} options ajax options
             * @param {Number} interval time in ms to repeat
             * @param {Function} callback function to call when fetchHtml succeeds
             * @param {Boolean} [isStatic] tells the ajax request whether to add the pjax headers or not
             * @param {Boolean} [isHtml] will return a quickly built jQuery dom object
             * @return {Number} setInterval id
             */
            recurringFetchData: function(path, options, interval, callback, isStatic, isHtml){
                return RequestManager.recurringFetchData(path, options, interval, callback, isStatic, isHtml);
            }
        };

        /**
         * @global
         */
    window.stateManager = new StateManager();
    return window.stateManager;
});
