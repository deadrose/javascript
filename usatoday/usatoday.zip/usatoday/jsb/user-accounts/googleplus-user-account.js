
define('user-accounts/googleplus-user-account',[
    'jquery',
    'underscore',
    'user-manager',
    'user-accounts/base-user-account',
    'third-party-apis/google/googleplus',
    'cookie'
],
function(
    $,
    _,
    UserManager,
    BaseUserAccount,
    Googleplus
)
    {
    'use strict';
        var GooglePlusUserAccount = BaseUserAccount.extend({
            initialize: function(options){

                BaseUserAccount.prototype.initialize.call(this, options);
                this.user = {};

                UserManager.registerAccount(this);
            },
            _handleGetUserInfo:function() {
                return Googleplus.getUserInfo()
                    .done(_.bind(function(userInfo){
                        this.user = userInfo;
                    }, this));
            },
            _handleLogin: function(isAutoLogin){
                var loginMethod = isAutoLogin ? 'getAuthStatus' : 'signInUser';
                return Googleplus[loginMethod]()
                    .then(_.bind(function(resp){
                        this.sessionToken = resp.access_token;
                        return this._handleGetUserInfo();
                    }, this))
                    .fail(_.bind(function(){
                        this.logout();
                    }, this));

            },
            _handleLogout: function(){
                if (this.sessionToken) {
                    return Googleplus.signOutUser(this.sessionToken);
                } else {
                    return $.Deferred().resolve();
                }
            },
            getName: function(){
                return 'google';
            },

            getUserToken: function(){
                return this.sessionToken;
            },

            getUserId: function(){
                return this.user.id;
            },

            getUserAvatar: function(){
                if (this.user.image) {
                    return this.user.image.url;
                } else {
                    return "";
                }
            },

            getUserFirstName: function(){
                if (this.user.name) {
                    return this.user.name.givenName;
                } else {
                    return "";
                }
            },

            getUserLastName: function(){
                if (this.user.name){
                    return this.user.name.familyName;
                } else {
                    return "";
                }
            }

        });

        return new GooglePlusUserAccount();
    }
);