
/*global FB:true*/
define('user-accounts/facebook-user-account',[
    'jquery',
    'underscore',
    'pubsub',
    'user-accounts/base-user-account',
    'user-manager',
    'third-party-apis/facebook/facebook',
    'cookie'
],
function(
    $,
    _,
    PubSub,
    BaseUserAccount,
    UserManager,
    Facebook
)
    {
        'use strict';
        var FacebookUserAccount = BaseUserAccount.extend({
            initialize: function(options){
                BaseUserAccount.prototype.initialize.call(this, options);
                this.user = {};
                UserManager.registerAccount(this);
            },

            /**
             * Handles getting the user's information.
             * @returns {Deferred} promise that resolves when the account has user info
             * @private
             */
            _handleGetUserInfo: function() {
                return Facebook.loadScript().then(function(){
                    return $.Deferred(function(defer) {
                        FB.api('/me?fields=name,first_name,last_name,gender,picture', function (response) {
                            if (!response || response.error) {
                                console.error("Facebook returned erroneous response!", response);
                                defer.reject(response);
                            } else {
                                defer.resolve(response);
                            }
                        });
                    });
                });
            },

            /**
             * Handles logging the user in to Facebook.
             * @returns {Deferred} promise that resolves when the login succeeds
             * @private
             */
            _handleLogin: function(isAutoLogin) {
                var loginPromise;
                if (isAutoLogin) {
                    // user has logged in before, so lets check status
                    loginPromise = this._getLoginStatus();
                } else {
                    loginPromise = this._loginUser();
                }
                return loginPromise
                    .then(_.bind(function(authResponse){
                        this.sessionToken = authResponse.accessToken;
                        return this._handleGetUserInfo();
                    }, this))
                    .done(_.bind(function(userData){
                        this.user = userData;
                    }, this))
                    .fail(_.bind(function(status){
                        // we need to call logout instead of rejecting the promise to account for
                        // when user cancels login window (which is not technically a login failure!)
                        if (status === 'unknown') {
                            this.logout();
                        }
                    }, this));
            },


            /**
             * Gets user's logged in status.
             * @returns {*} the user's ID, a valid access token, a signed
             * request, and the time the access token and signed request each expire
             * @private
             */
            _getLoginStatus: function () {
                return Facebook.loadScript().then(function(){
                    return $.Deferred(function(defer){
                        FB.getLoginStatus(function (response) {
                            if (response.status === 'connected') {
                                // user is logged in and has authenticated your app for the user
                                defer.resolve(response.authResponse);
                            } else {
                                // user is logged in to Facebook but has not authenticated the app or
                                // the user isn't logged in to Facebook
                                defer.reject(response.status);
                            }
                        });
                    });
                });
            },

            /**
             * Logs in a user using Facebook's authentication.
             * @returns {Deferred}
             * @private
             */
            _loginUser: function () {
                return Facebook.loadScript().then(function () {
                    return $.Deferred(function(defer){
                        FB.login(function (response) {
                            if (response.status === 'connected') {
                                // user successfully logged in!
                                defer.resolve(response.authResponse);
                            } else {
                                // user either cancelled login window or has not authorized the app
                                defer.reject(response.status);
                            }
                        }, {scope: Facebook.getUserPermissions() });
                    });
                });
            },

            /**
             * Handles logging out a facebook user.
             * @returns {Deferred} Returns a promise that resolves when done logging the user out.
             * @private
             */
            _handleLogout: function(){
                this.user = {};
                this.sessionToken = null;
                return Facebook.loadScript().then(function() {
                    // we don't use the logout callback because it won't be fired if the user is already logged out
                    FB.logout();
                });
            },

            getName: function(){
                return 'facebook';
            },

            getUserToken: function(){
                return this.sessionToken;
            },

            getUserId: function(){
                return this.user.id;
            },

            getUserAvatar: function(){
                if (this.user.picture && this.user.picture.data) {
                    return this.user.picture.data.url;
                } else {
                    return "";
                }
            },

            getUserFirstName: function(){
                return this.user.first_name;
            },

            getUserLastName: function(){
                return this.user.last_name;
            }
        });

        return new FacebookUserAccount();
    }
);