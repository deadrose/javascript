
/**
 * @fileoverview UGC App.
 */
define('apps/ugc-app',[
    'jquery',
    'underscore',
    'base-app',
    'site-manager'
],
    function(
        $,
        _,
        BaseApp,
        SiteManager
        ) {
        "use strict";

        /**
         * Page class.
         */
        var UGCApp = BaseApp.extend({

            /**
             * animates page to page within an app
             * @param {String} fromUrl path we're leaving
             * @param {String} toUrl path we're about to go to
             * @return {Deferred} a promise object that resolves when the animation is complete
             */
            animateChangePagePreData: function(fromUrl, toUrl){
                SiteManager.scrollTop(0);
            }

        });

        /**
         * Return page class.
         */
        return UGCApp;
    });
