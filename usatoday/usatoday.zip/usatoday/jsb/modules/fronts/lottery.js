
/**
 * @fileoverview Lottery module view.
 * @author Jonathan Hensley <jhensley@gannett.com>
 */
define('modules/fronts/lottery',[
    'jquery',
    'underscore',
    'baseview',
    'state',
    'utils',
    'ui/dropdown'
],
    function(
        $,
        _,
        BaseView,
        StateManager,
        Utils,
        Dropdown
        ) {
        "use strict";
        /**
         * View class.
         */
        var LotteryView = BaseView.extend({

            /**
             * Initialize view.
             * @param {object} options to pass in module options
             */
            initialize: function(options) {

                options = $.extend({
                    refreshDelay: 6000, //ms
                    refresh: false
                },options);
                _.bindAll(this, 'updateLottery');
                BaseView.prototype.initialize.call(this,options);
                if (this.options.refresh) {
                    this.subviews.refreshInterval = StateManager.recurringFetchHtml('/lottery/front-module', null, this.options.refreshDelay, this.updateLottery);
                } else {
                    StateManager.fetchHtml('/lottery/front-module').done(this.updateLottery);
                }
            },

            updateLottery: function(html){
                this.$el.html(html);
                this.setupDropdown();
            },

            setupDropdown: function(){
                if (this.subviews.selectDropdown) {
                    this.subviews.selectDropdown.destroy();
                }
                this.subviews.selectDropdown = new Dropdown({
                    el: this.$('.lottery-state-picker-dropdown')
                });
            }


        });

        /**
         * Return view class.
         */
        return LotteryView;
    }
);
