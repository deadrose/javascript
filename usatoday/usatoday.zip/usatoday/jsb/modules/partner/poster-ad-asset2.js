
define('modules/partner/poster-ad-asset2',['jquery', 'underscore', 'baseview', 'state', 'site-manager', 'utils', 'directAdPosition'], function($, _, BaseView, StateManager, SiteManager, Utils, DirectAdPosition) {

    'use strict';

    var PosterAd2 = BaseView.extend({

        /*
         * @param {object}  [options] -
         *      minTimeForAd:    {num} minimum amount of milliseconds before refreshing the ad call
         *      topMargin:       {num} The margin above the poster scroll and below the header when the
         *                        ad is in a "fixed" position (docked to the top)
         *      disableRefresh:  {Boolean} Setting to True disables the refreshing action of the ad,
         *                        a requirement for USAT
         */

        initialize : function(options) {
            _.bindAll(this, '_overlayScrollListener', '_handleResizeWindow', 'onSecondAdReady', '_isInViewport');
            options = $.extend({
                minTimeForAd : 5000,
                topMargin : 30,
                disableRefresh : Utils.getNested(window.site_vars, 'ads', 'poster_scroll_refresh_disabled')
            }, options);

            var activeApp = StateManager.getActiveApp();

            this.$win = Utils.get('win');
            this.header = SiteManager.getHeader();
            this.overlayScrollListenerThrottle = _.throttle(this._overlayScrollListener, 16, {
                'leading' : false,
                'trailing' : true
            });
            this.$win.on('scroll.' + this.cid, this.overlayScrollListenerThrottle).on('resize.' + this.cid, this._handleResizeWindow);
            this._handleResizeWindow();
            this._setArticleDimensions();
            this.posterAd2Height = 0;

            /* handle breaking bar opening and closing*/
            this.pubSub = {
                'breakingbar:after:open' : this._overlayScrollListener,
                'breakingbar:after:close' : this._overlayScrollListener
            };

            this.$adEl = this.$('.poster-scroll-ad');
            this.$otherAds = activeApp.$('.partner-asset-right-ad,.datasphere-community-module');

            BaseView.prototype.initialize.call(this, options);
        },

        /*
         * Our Scroll Listener
         *
         */

        _overlayScrollListener : function() {
            // bail out if the height of the module is not
            // tall enough to show the smallest ad size height
            this.moduleOffsetTop = this.$el.offset().top;

            if (this._getModuleHeight() < (this.posterAd2Height || 250)) {
                this.hide();
                return;
            }

            this._goToState(this._getCurrentState());

            this._handleRequestAds();
        },

        /*
         * Our Ad can be in 4 states, depending on other states of
         * the current viewport, modules, and other ads:
         *
         * 1.   'hidden' = Hidden
         * 2.   'dockTop' = In it's place in the natual
         *       flow of the document, at the top of the
         *       module
         * 3.   'fixed' = Docked to the top of the viewport
         * 4.   'dockBottom' = Docked to the bottom of the
         *       sidebar/article
         */

        _getCurrentState : function() {
            // hide ad when another ad is in view
            // hide ad when we're not in view so we don't request/refresh ads that can't be seen
            if (this._isOtherAdinViewPort() || !this._isInViewport(this.$el, this._getModuleHeight())) {
                return 'hidden';
            } else if (this._shouldDockBottom()) {
                return 'dockBottom';
            } else if (this._shouldFixAd()) {
                return 'fixed';
            } else {
                return 'dockTop';
            }
        },

        _goToState : function(state) {
            if (state === this.state) {
                return;
            }
            if (this.state === 'hidden') {
                // no longer hidden
                this.$adEl.css('opacity', '1');
            }
            if (state === 'hidden') {
                // hide
                this.$adEl.css('opacity', '0');
            } else if (state === 'fixed') {
                this.$adEl.css({
                    position : 'fixed',
                    top : this._getHeaderHeight() + this.options.topMargin
                });
            } else if (state === 'dockTop') {
                this.$adEl.css({
                    position : 'static',
                    top : 'auto'
                });
            } else if (state === 'dockBottom') {
                this._dockBottom();
            }
            this.state = state;
        },

        /**** GETTERS/ENVIRONMENT CHECKERS ***/

       _shouldFixAd : function() {
            return (this.moduleOffsetTop - this.options.topMargin) < this._getViewportOffset();
        },

        _getViewportOffset : function() {
            return Utils.getScrollPosition() + this._getHeaderHeight();
        },

        _shouldDockBottom : function() {
            var scrollThresholdForDocking = this._getModuleOffsetBottom() - this.posterAd2Height - this.options.topMargin;
            return scrollThresholdForDocking < this._getViewportOffset();
        },

        _getHeaderHeight : function() {
            if (this.header) {
                return this.header.getFixedHeight();
            }
            return 0;
        },

        _isOtherAdinViewPort : function() {
            return _.find(this.$otherAds, function($el, index) {
                return this._isInViewport($el);
            }, this) !== undefined;
        },

        _isInViewport : function(el, heightOverride) {
            var $el = $(el), elTop = $el.offset().top, elBottom = elTop + (heightOverride || $el.outerHeight()), viewportTop = this._getViewportOffset(), viewportBottom = viewportTop + this.winHeight - this._getHeaderHeight();

            return !(elBottom < viewportTop || viewportBottom < elTop);
        },

        _isTimeToRefresh : function() {
            // no need to wait on the first refresh
            if (this.lastAdRefreshedTime) {
                var currentTime = (new Date()).getTime();
                return (currentTime - this.lastAdRefreshedTime) >= this.options.minTimeForAd;
            } else {
                return true;
            }
        },

        /**
         * height of this module should be from its top
         * to the bottom of the sidebar. It should take up
         * the entire space that is left in the sidebar. Since
         * can't set a height that is 100% of available space,
         * need to use this function to get what the height is.
         *
         * (article offset top + article height) - module offset top = height
         *
         * returns {Integer} height from top of module to bottom of sidebar
         */
        _getModuleHeight : function() {
            return this.articleOffsetTop + this.articleHeight - this.moduleOffsetTop;
        },

        _getModuleOffsetBottom : function() {
            return this.moduleOffsetTop + this._getModuleHeight();
        },

        _hasScrolledAViewportHeight : function() {
            var windowOffset = Utils.getScrollPosition(), howFarImoved = Math.abs(windowOffset - this.scrollTopAdRequestedAt);
            return howFarImoved >= this.winHeight;
        },

        /**** Handlers/Actions ***/

        _handleResizeWindow : function() {
            this.winHeight = this.$win.height();
        },

        _handleRequestAds : function() {
            if (this.state === 'dockTop' && !this.subviews.ad) {
                this._requestAd();
            } else if ((this.state === 'fixed' && !this.subviews.ad) || (this.state === 'fixed' && !this.options.disableRefresh && this._hasScrolledAViewportHeight() && this._isTimeToRefresh())) {
                this._requestAd();
            }
        },

        _dockBottom : function() {
            this.$adEl.css({
                position : 'absolute',
                top : this.articleHeight - this.posterAd2Height + this.articlePositionTop
            });
        },

        _setArticleDimensions : function() {
            var articleBody = StateManager.getActiveApp().$('article > div[role=main]');
            if (articleBody.length) {
                this.articleHeight = articleBody.height();
                this.articleOffsetTop = articleBody.offset().top;
                this.articlePositionTop = articleBody.position().top;
            }
        },

        _requestAd : function() {
            var ad = this.subviews.ad;
            if (!ad) {
                var adSizes = ['mediumrectangle'], maxAdSize = 600 + this.options.topMargin;
                if (this._getModuleHeight() >= maxAdSize && (this.winHeight - this._getHeaderHeight()) >= maxAdSize) {
                    adSizes = adSizes.concat(['halfpage', 'portrait', 'filmstrip']);
                }
                this.subviews.ad = new DirectAdPosition({
                    el : this.$adEl,
                    adSizes : adSizes,
                    adPlacement : 'poster_scroll',
                    adType : 'poster',
                    onAdReady : this.onSecondAdReady,
                    pageInfo : StateManager.getActivePageInfo()
                });
            } else if (!ad.isAdReady()) {
                return;
            } else {
                ad.refreshPosition();
            }
            this.scrollTopAdRequestedAt = Utils.getScrollPosition();
        },

        onSecondAdReady : function() {
            this.subviews.ad.show();
            this.posterAd2Height = this.$adEl.outerHeight();
            this.lastAdRefreshedTime = (new Date()).getTime();
            this._overlayScrollListener();
            if (this.state === 'dockBottom') {
                this._dockBottom();
            }
        },

        /**
         * Clean up view.
         * Removes event handlers and element (optionally).
         * @param {boolean} removeEl option to also remove View from DOM.
         */
        destroy : function(removeEl) {
            this.$win.off('.' + this.cid);
            BaseView.prototype.destroy.call(this, removeEl);
        }


    });
    return PosterAd2;
});