

/**
 * @fileoverview Dropdown in the global navigation.
 * @author ekallevig@gannett.com (Erik Kallevig)
 *
 */

define('modules/header/site-nav-dropdown',[
    'jquery',
    'underscore',
    'backbone',
    'baseview',
    'state',
    'easing'
],
function(
    $,
    _,
    Backbone,
    BaseView,
    StateManager
) {

"use strict";

/**
 * View class.
 */
var SiteNavDropdownView = BaseView.extend({

    // Events.
    events: {
        'mouseenter': 'onMouseEnter',
        'mouseleave': 'onMouseLeave',
        'click .site-nav-dropdown': 'closeDropdown'
    },

    /**
     * Initialize the view.
     */
    initialize: function(options) {
        _.bindAll(this, 'openDropdown', 'closeDropdown');
        this.fadeSpeed = 80;
        this.showDelay = 120;
        // this.hideDelay = 100;
        this.$dropdown = this.$('.site-nav-dropdown');
        BaseView.prototype.initialize.call(this, options);
    },


    onMouseEnter: function(e) {
        clearTimeout(this.hideTimer);
        this.isMouseOnDropdown = true;
        this.openDropdown(e);
        // this.showTimer = setTimeout(_.partial(this.openDropdown, e), this.showDelay);
    },

    onMouseLeave: function(e){
        // clearTimeout(this.showTimer);
        this.isMouseOnDropdown = false;
        // this.closeDropdown(e);
        this.hideTimer = setTimeout(_.partial(this.closeDropdown, e), this.hideDelay);
    },

    /**
     * Close weather dropdown.
     */
    closeDropdown: function(e) {
        if (!this.isDropdownOpen || (e.type == 'mouseout' && this.isMouseOnDropdown)) {
            return;
        }
        this.isDropdownOpen = false;
        this.animate(this.$dropdown, 'opacity', 0, this.fadeSpeed).done(_.bind(function(){
            this.$dropdown.css('display', 'none');
        }, this));
        this.$el.removeClass('site-nav-active-item');
    },

    /**
     * Open weather dropdown.
     */
    openDropdown: function(e) {
        if (this.isDropdownOpen || (e.type == 'mouseover' && !this.isMouseOnDropdown)) return;
        this.isDropdownOpen = true;
        this.$el.addClass('site-nav-active-item');
        this.$dropdown.css('display', 'block');
        this.animate(this.$dropdown, 'opacity', 1, this.fadeSpeed);
    }

});


/**
 * Return view class.
 */
return SiteNavDropdownView;

});
