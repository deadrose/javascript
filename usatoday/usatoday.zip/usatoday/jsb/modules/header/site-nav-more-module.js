

/**
 * @fileoverview More dropdown in the global navigation.
 * @author ekallevig@gannett.com (Erik Kallevig)
 *
 */

define('modules/header/site-nav-more-module',[
    'underscore',
    'modules/header/site-nav-dropdown'
],
function(
    _,
    SiteNavDropdown
) {

"use strict";
var MoreDropdownView = SiteNavDropdown.extend({

    CLASS_ROOT: 'site-nav-more-dropown-front-toggle-',
    LINK_CLASS: 'site-nav-more-dropown-front-toggle-link',
    ACTIVE_LINK_CLASS: 'site-nav-more-dropown-front-toggle-link-active',

    initialize: function(options) {
        this.pubSub = {
            'page:load': this.onPageLoad
        };
        this.$defaultLink = this.$('.' + this.CLASS_ROOT + 'default');
        this.$bigPageLink = this.$('.' + this.CLASS_ROOT + 'bigpage');
        _.bindAll(this, 'onPageLoad');
        SiteNavDropdown.prototype.initialize.call(this, options);
    },

    onPageLoad: function(e) {
        var newType = e.contenttype && e.contenttype == 'the big page' ? 'bigpage' : 'other';
        if (this.currentActiveType !== newType) {
            this.currentActiveType = newType;
            this.$('.' + this.LINK_CLASS).removeClass(this.ACTIVE_LINK_CLASS);
            if (newType == 'bigpage') {
                this.$bigPageLink.addClass(this.ACTIVE_LINK_CLASS);
            } else {
                this.$defaultLink.addClass(this.ACTIVE_LINK_CLASS);
            }
        }
    }

});


return MoreDropdownView;

});
