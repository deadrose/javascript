
define('modules/ugc/ugc-base-view',[
    'jquery',
    'underscore',
    'baseview',
    'modules/ugc/ugc-user',
    'pubsub'
],
    function(
        $,
        _,
        BaseView,
        UGCUser,
        PubSub
        ) {
        "use strict";
        /**
         * Handles unprotected and login-required views.
         * @author Mark Kennedy <mdkennedy@gannett.com>
         */
        var UGCBaseView = BaseView.extend({

            /**
             * Initialize page.
             * @param {Object} options Page options passed during init.
             */
            initialize: function(options) {
                BaseView.prototype.initialize.call(this, options);

                this.$views = this.$('.ugc-upload-form-view');

                PubSub.on('ugc:user:statuschange', function(){
                    var currentView = this.getCurrentView();
                    // set current view to null because user could be not yet logged in.
                    if (currentView) {
                        if (this.isViewProtected(currentView)) {
                            this.revealView([]);
                        }
                        this.revealView(currentView);
                    }
                }, this);

            },

            /**
             * Reveals a view.
             * @param {jQuery|HTMLElement} view The element to show
             * @returns {Deferred} Returns a promise that resolves when the the element reveals itself
             */
            revealView: function(view){
                var $view = $(view);
                view = $view[0];
                // TODO: what happens when this function is called with another view before previous views are revealed?
                if ($view.hasClass('ugc-upload-form-view-login-required')) {
                    // view requires login!
                    return this._revealProtectedView(view);
                } else {
                    // view does not require login!
                    return this._revealUnprotectedView(view);
                }
            },

            /**
             * Reveals a view that does not require user login.
             * @param {HTMLElement} view The view to reveal
             * @returns {Deferred}
             * @private
             */
            _revealUnprotectedView: function(view) {
                return this._transitionView(view);
            },

            /**
             * Transitions a view into existence.
             * @param {HTMLElement} view The view to show
             * @returns {Deferred} Returns a promise that resolves when done
             * @private
             */
            _transitionView: function(view) {
                var previousView = this.getCurrentView();
                // resolve immediately if view is already showing
                if (previousView === view) {
                    return $.Deferred().resolve();
                }
                this.setCurrentView(view);
                return this._handleRevealView(view, previousView);
            },

            /**
             * Sets a view as the active one.
             * @param {jQuery|HTMLElement} view The view to set as active
             */
            setCurrentView: function(view) {
                this._currentView = view;
                this.$views.removeClass('view-active');
                $(view).addClass('view-active');
            },

            /**
             * Reveals a view that requires login.
             * @params {HTMLElement} view The view to reveal
             * @private
             */
            _revealProtectedView: function(view) {
                var getUserInfoPromise = UGCUser.getUserInfo();
                if (getUserInfoPromise.state() === 'rejected') {
                    // unauthorized user!
                    return $.Deferred().reject();
                } else {
                    // authorized user!
                    return getUserInfoPromise.then(_.bind(function() {
                        return this._transitionView(view);
                    }, this));
                }
            },

            /**
             * Override-able function to handle the revealing of a view (div).
             * @param {HTMLElement} view The view that is requested to be shown
             * @param {HTMLElement} previousView The original view before the new one that was requested
             * @returns {Deferred} Returns a promise that resolves when the is revealed
             */
            _handleRevealView: function(view, previousView) {
                var $view = $(view),
                    $previousView = $(previousView);
                $previousView.hide();
                $view.show();
                return $.Deferred().resolve();
            },

            /**
             * Gets the currently active view.
             * @returns {HTMLElement} Returns current view if there is one and empty array if not
             */
            getCurrentView: function() {
                return this._currentView;
            },

            /**
             * Checks if a view is login-required (password-protected).
             * @param {jQuery|HTMLElement} view
             */
            isViewProtected: function(view) {
                return $(view).hasClass('ugc-upload-form-view-login-required');
            },

            /**
             * Destroys the view.
             */
            destroy: function() {
                this.revealView([]);
                PubSub.off('ugc:user:statuschange');
                BaseView.prototype.destroy.call(this);
            }

        });

        /**
         * Return page class.
         */
        return UGCBaseView;
    });
