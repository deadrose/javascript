
/**
 * @fileoverview UGC's Base Upload View.
 * @author Mark Kennedy
 */
define('modules/ugc/ugc-base-upload-view',[
    'jquery',
    'underscore',
    'modules/ugc/ugc-base-view',
    'modules/ugc/ugc-base-upload-form',
    'modules/ugc/ugc-user',
    'third-party-apis/google/google-maps',
    'state'
],
    function(
        $,
        _,
        UGCBaseView,
        UGCBaseUploadForm,
        UGCUser,
        GoogleMapsApi,
        StateManager
        ) {
        "use strict";


        var UGCBaseUploadView = UGCBaseView.extend({

            /**
             * Initialize page.
             * @param {Object} options Page options passed during init.
             */
            initialize: function(options) {

                options = $.extend({
                    uploadFormOptions: {}
                }, options);

                UGCBaseView.prototype.initialize.call(this, options);

                _.bindAll(this, '_onFileUploadSuccess', '_onFileRemove');

                // setup file success wrappers
                this.$successUploadedFileWrappers = this.$('.ugc-upload-success-file');
                this.$successUploadedFileWrappers.addClass('ugc-upload-success-file-empty');

                // stop global site refresh, we dont want UGC upload content being wiped!
                StateManager.stopRefreshTimer();

                this.setupForm();

            },

            /**
             * Sets up the upload form.
             */
            setupForm: function() {
                return UGCUser.getUserInfo()
                    .done(_.bind(function (userInfo) {
                        var uploadFormOptions = $.extend({}, this._buildUploadFormOptions(), {userInfo: userInfo});
                        if (!this.subviews.uploadForm) {
                            this.subviews.uploadForm = new UGCBaseUploadForm(uploadFormOptions);
                        }
                    }, this));

            },

            /**
             * Builds the options for the instantiation of upload form.
             * @returns {*}
             * @private
             */
            _buildUploadFormOptions: function() {
                return $.extend({}, {
                    el: this.$('.ugc-front-upload-form'),
                    onFileUploadSuccess: this._onFileUploadSuccess,
                    onFileRemove: this._onFileRemove
                }, this.options.uploadFormOptions);
            },

            /**
             * When the form is successfully submitted.
             * @private
             */
            _onSubmitSuccess: function(){
                if (this.options.onSubmitSuccess) {
                    this.options.onSubmitSuccess();
                }
            },

            /**
             * When form submission fails.
             * @private
             */
            _onSubmitFail: function(){
                if (this.options.onSubmitFail) {
                    this.options.onSubmitFail();
                }
            },

            /**
             * When a file is uploaded successfully.
             * @param {File} file The file object
             * @param {Object} fileMap The file map
             * @private
             */
            _onFileUploadSuccess: function(file, fileMap) {
                // only set location with the first file with location data
                if (!this._hasUploadLocationBeenSetByFile) {
                    this.getUploadLocationByFile(file).done(_.bind(function(location){
                        this.getForm().setUploadLocation(location);
                        this._hasUploadLocationBeenSetByFile = true;
                    }, this));
                }
                this.addFileToUploadSuccessMarkup(fileMap);
            },

            /**
             * Gets a geolocation based on a file object's data.
             * @param {Object} fileData The file data
             * @returns {Deferred} Returns a promise that resolves when a location is successfully obtained
             */
            getUploadLocationByFile: function(fileData) {
                var lat = fileData.geo_latitude,
                    lon = fileData.geo_longitude;
                // sometimes files dont have lat and lon!
                if (lat && lon) {
                    return this.getGeolocationByLatLon(lat, lon);
                } else {
                    return $.Deferred().reject();
                }
            },

            /**
             * Converts a latitude and longitude coordinates into a human-readable location
             * @param {Number} lat Latitude
             * @param {Number} lon Longitude
             * @returns {Deferred} Returns a promise that resolves when a geolocation is obtained successfully
             */
            getGeolocationByLatLon: function(lat, lon) {
                var deferred = $.Deferred();
                GoogleMapsApi.getGeolocation(lat, lon).done(_.bind(function(resp){
                    // format the response into a normalized location object before resolving
                    var location = GoogleMapsApi.formatGeolocationResponse(resp);
                    deferred.resolve(location);
                }, this));
                return deferred.promise();
            },

            /**
             * When a file is removed from upload form.
             * @param {File} file The file object
             * @param {Object} fileMap The file map that was removed
             * @private
             */
            _onFileRemove: function(file, fileMap) {
                this.removeFileFromUploadSuccessMarkup(fileMap);
            },

            /**
             * Adds a file to the upload success div.
             * @param fileMap The file map object
             */
            addFileToUploadSuccessMarkup: function(fileMap) {
                var fileId = fileMap.fileId,
                    $mediaEl = this._buildUploadSuccessMediaElement(fileMap),
                    $nextEmptyFileWrapper = this.$successUploadedFileWrappers.filter('.ugc-upload-success-file-empty').eq(0);
                $nextEmptyFileWrapper.data('file-id', fileId);
                $nextEmptyFileWrapper.append($mediaEl);
                $nextEmptyFileWrapper.removeClass('ugc-upload-success-file-empty');
            },

            /**
             * Removes a file from the upload success div.
             * @param {File} fileMap The file map object
             */
            removeFileFromUploadSuccessMarkup: function(fileMap) {
                var $fileWrapper = this.$successUploadedFileWrappers.filter(function() {
                    return $.data(this, 'file-id') === fileMap.fileId;
                });
                this.removeFileDataFromUploadSuccessMarkup($fileWrapper);
            },

            /**
             * Removes the file data from an upload success div.
             * @param {jQuery} $div The index of the div to be removed
             */
            removeFileDataFromUploadSuccessMarkup: function($div) {
                $div.removeData('file-id');
                $div.empty();
                $div.addClass('ugc-upload-success-file-empty');
            },

            /**
             * Removes all files from the upload success div.
             */
            resetUploadSuccessMarkup: function() {
                _.each(this.$successUploadedFileWrappers, function(fileWrapper) {
                    this.removeFileDataFromUploadSuccessMarkup($(fileWrapper));
                }, this);
            },

            /**
             * Builds the html markup for the media element
             * @param fileMap The file map
             * @returns {jQuery}
             * @private
             */
            _buildUploadSuccessMediaElement: function(fileMap) {
                var el = fileMap.getHtmlElement(),
                    sourceUrl, width, height, orientation,
                    file = fileMap.file,
                    mediaType = file.type.split('/')[0],
                    isFilePreviewable = fileMap.isPreviewable(),
                    genericMediaClass = 'ugc-upload-success-media';

                if (el) {
                    sourceUrl = el.src;
                    width = el.videoWidth || el.width;
                    height = el.videoHeight || el.height;
                }

                var $mediaEl;
                if (isFilePreviewable && mediaType === 'video') {
                    $mediaEl = $('<video src="' + sourceUrl + '">');
                } else if (isFilePreviewable && mediaType === 'image') {
                    $mediaEl = $('<img src="' + sourceUrl + '">');
                } else {
                    $mediaEl = $('<div>');
                }

                // add orientation class
                if (width && height && isFilePreviewable) {
                    orientation = width > height ? 'landscape' : 'portrait';
                    $mediaEl.addClass(genericMediaClass + '-' + orientation);
                }
                $mediaEl.addClass(genericMediaClass);
                $mediaEl.addClass(genericMediaClass + '-' + mediaType);

                var previewTypeClass;
                if (isFilePreviewable) {
                    previewTypeClass = genericMediaClass + '-preview';
                } else {
                    previewTypeClass = genericMediaClass + '-no-preview';
                }
                $mediaEl.addClass(previewTypeClass);

                return $mediaEl;
            },

            /**
             * Gets the upload form subview.
             * @returns {Object} The upload form subview
             */
            getForm: function() {
                return this.subviews.uploadForm;
            },

            /**
             * Gets the current state of the upload form.
             * @returns {String} returns 'notSubmitted', 'submitPending', 'submitFailed' or 'submitSuccess'
             */
            getFormSubmitStatus: function() {
                var form = this.getForm();
                if (form) {
                    return form.getSubmitStatus();
                } else {
                    return 'notSubmitted';
                }
            },

            /**
             * Get the default upload location for the upload form.
             * @returns {*|{latitude: number, longitude: number}}
             */
            getDefaultUploadLocation: function() {
                if (this.subviews.uploadForm) {
                    return this.subviews.uploadForm.getDefaultUploadLocation();
                } else {
                    return '';
                }
            },

            /**
             * Reset.
             */
            reset: function() {
                if (this.subviews.uploadForm) {
                    this.subviews.uploadForm.reset();
                }
                this.resetUploadSuccessMarkup();
                this._hasUploadLocationBeenSetByFile = false;
            },

            /**
             * Destroys the view.
             */
            destroy: function() {
                StateManager.startRefreshTimer();
                UGCBaseView.prototype.destroy.call(this);
            }

        });

        /**
         * Return page class.
         */
        return UGCBaseUploadView;
    });
