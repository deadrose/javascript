
/**
 * @fileoverview UGC Utility bar upload view.
 * @author Mark Kennedy <mdkennedy@gannett.com>
 */
define('modules/ugc/ugc-utility-bar-upload-view',[
    'jquery',
    'underscore',
    'modules/ugc/ugc-base-upload-view',
    'user-manager',
    'modules/ugc/ugc-user',
    'easing'
],
function(
    $,
    _,
    UGCBaseUploadView,
    UserManager,
    UGCUser
) {
    'use strict';

    /**
     * View class.
     */
    var UGCUtilityBarUploadView = UGCBaseUploadView.extend({

        el: '.ugc-util-bar-flyout-upload-form-view-container',

        events: {
            'click .ugc-util-bar-flyout-upload-form-contribute-more-btn': 'onClickContributeMoreButton',
            'click .ugc-util-bar-flyout-upload-form-view-upload-teaser': 'onClickUploadTeaserButton',
            'click .ugc-util-bar-flyout-submit-btn': 'onClickSubmitButton',
            'click .ugc-util-bar-flyout-cancel-btn': 'onClickCancelButton',
            'click .ugc-util-bar-flyout-be-first-to-contribute-graphic-signedin': 'onBeFirstToContributeButtonClick',
            'click .ugc-login-btn': 'onClickLoginButton',
            'click .ugc-util-bar-flyout-upload-form-login-fail-try-again': 'onClickLoginFailTryAgain'
        },

        initialize: function(options) {

            _.bindAll(this, 'onFormSubmitSuccess', 'onFormSubmitFail');

            options = $.extend({
                onRefresh: null,
                uploadFormOptions: {
                    el: this.$('.ugc-util-bar-flyout-upload-form'),
                    onSubmitSuccess: this._onFormSubmitSuccess,
                    onSubmitFail: this._onFormSubmitFail
                }
            }, options);

            this.pubSub = {
                'ugc:user:statuschange': this.onUserStatusChange
            };

            UGCBaseUploadView.prototype.initialize.call(this, options);

            this.$views = this.$('.ugc-upload-form-view');
            this.$uploadView = this.$views.filter('.ugc-upload-form-view-upload');
            this.$submitSuccessView = this.$views.filter('.ugc-upload-form-view-submit-success');
            this.$submitFailView = this.$views.filter('.ugc-upload-form-view-submit-fail');
            this.$loggingInView = this.$views.filter('.ugc-upload-form-view-logging-in');
            this.$loginFailView = this.$views.filter('.ugc-upload-form-view-login-fail');
            this.$notSignedInView = this.$views.filter('.ugc-upload-form-view-logged-out');
            this.$uploadTeaserView = this.$views.filter('.ugc-util-bar-flyout-upload-form-view-upload-teaser');

            this.show();

        },

        /**
         * Shows the upload view.
         */
        show: function() {

            var setupFormPromise = this.setupForm(),
                loginStatus = UGCUser.getLoginState();
            var logginInPromise;

            if (loginStatus === 'loggedOut') {
                return this.revealView(this.$notSignedInView);
            } else if (loginStatus === 'loginFailed') {
                return this.revealView(this.$loginFailView);
            } else {
                // logging in or logged in!
                if (setupFormPromise.state() === 'pending') {
                    // show logging in view temporarily until we have user information
                    logginInPromise = this.revealView(this.$loggingInView);
                }
            }
            return $.when(logginInPromise).then(_.bind(function(){
                    this.revealView(this.$uploadTeaserView).fail(_.bind(function () {
                        this.revealView(this.$loginFailView);
                    }, this));
                }, this));
        },


        /**
         * Reveals a view.
         * @param {HTMLElement} view The view to reveal
         * @param {HTMLElement} previousView The original view
         * @returns {*} Returns a promise when done.
         */
        _handleRevealView: function(view, previousView){
            var deferred = $.Deferred(),
                $view = $(view),
                viewHeight = $view.height();
            $(previousView).hide();
            this.updateViewContainerHeight(viewHeight).done(_.bind(function(){
                $view.fadeIn(400, _.bind(function() {
                    deferred.resolve();
                    if (this.options.onRefresh) {
                        this.options.onRefresh();
                    }
                }, this));
            }, this));
            return deferred.promise();
        },

        /**
         * Animates the container of all the views to a specific height.
         * @param {Number} viewHeight
         * @returns {Deferred}
         */
        updateViewContainerHeight: function(viewHeight) {
            var deferred = $.Deferred(),
                easing,
                duration;
            if (viewHeight === 0) {
                easing = 'easeOutQuad';
                duration = 160;
            } else {
                easing = 'easeOutBack';
                duration = 400;
            }
            this.$el.stop().animate({'height': viewHeight + 'px'}, {
                duration: duration,
                easing: easing,
                complete: function(){
                    deferred.resolve();
                }
            });
            return deferred.promise();
        },

        /**
         * When the form is successfully submitted.
         * @param {Object} data Object containing successfully uploaded data.
         * @private
         */
        onFormSubmitSuccess: function(data){
            var post = data.post;
            // add username to view
            this.$submitSuccessView.find('.ugc-upload-form-submission-text-username').text(data.user.firstname);
            // add post groupid to link
            var $viewPostLink = this.$submitSuccessView.find('.ugc-util-bar-flyout-upload-form-view-your-contribution-btn');
            $viewPostLink.attr('href', _.template($viewPostLink.attr('href'), {post_id: post.groupid}));

            this.revealView(this.$submitSuccessView);
        },

        /**
         * When form submission fails.
         * @private
         */
        onFormSubmitFail: function () {
            this.revealView(this.$submitFailView);
        },

        /**
         * When contribute more button is clicked.
         */
        onClickContributeMoreButton: function() {
            this.reset();
            this.revealView(this.$uploadView);
        },

        /**
         * When teaser upload button is clicked.
         */
        onClickUploadTeaserButton: function() {
            this.revealView(this.$uploadView);
        },

        /**
         * When clicking on the upload form submit button.
         */
        onClickSubmitButton: function() {
            this.getForm().submit();
        },

        /**
         * When clicking on the upload form cancel button.
         */
        onClickCancelButton: function() {
            this.reset();
        },

        /**
         * When the login button is clicked.
         * @param {Event} e
         */
        onClickLoginButton: function(e){
            var userAccount = $(e.target).data('user-account');
            UserManager.loginUser(userAccount);
            e.preventDefault();
        },

        /**
         * When user clicks on 'try again' link when login has failed.
         */
        onClickLoginFailTryAgain: function(e) {
            e.preventDefault();
            this.show();
        },

        /**
         * When clicking on 'be first to contribute' graphic.
         */
        onBeFirstToContributeButtonClick: function() {
            this.revealView(this.$uploadView);
        },

        /**
         * When users status changes.
         */
        onUserStatusChange: function(){
            this.show();
        },

        /**
         * Reset.
         */
        reset: function() {
            var submitStatus = this.getFormSubmitStatus();
            UGCBaseUploadView.prototype.reset.call(this);
            if (submitStatus === 'submitSuccess' || submitStatus === 'submitFailed') {
                this.revealView(this.$uploadView);
            } else {
                this.revealView(this.$uploadTeaserView);
            }
        }

    });

    /**
     * Return view class.
     */
    return UGCUtilityBarUploadView;
});
