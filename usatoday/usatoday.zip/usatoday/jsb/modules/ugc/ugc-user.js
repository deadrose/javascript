
/**
 * @fileoverview Utility functions for the current UGC user.
 * @author Mark Kennedy
 */
define('modules/ugc/ugc-user',[
    'jquery',
    'underscore',
    'baseview',
    'user-manager',
    'pubsub',
    'managers/cachemanager',
    'state'
],
    function(
        $,
        _,
        BaseView,
        UserManager,
        PubSub,
        CacheManager,
        StateManager
        ) {
        "use strict";

        var UGCUser = BaseView.extend({

            initialize: function() {
                this.pubSub = {
                    'user:statuschange': this._onUserStatusChange
                };
                _.bindAll(this, '_getFilemobileUserInfo');
                this._loginPromise = $.Deferred();
                this._onUserStatusChange(null, UserManager.getLoginStatus());
                BaseView.prototype.initialize.call(this);
            },

            /**
             * When global user manager status changes.
             * @param account
             * @param loginStatus
             * @private
             */
            _onUserStatusChange: function(account, loginStatus){
                this._loginState = loginStatus;
                if (this._loginPromise.state() !== 'pending' && (loginStatus === 'loggedIn' || loginStatus === 'loggingIn')) {
                    this._loginPromise = $.Deferred();
                }
                if (loginStatus === 'loggedIn') {
                    this._loginState = 'loggingIn';
                    this._loginPromise.resolve();
                    // a little hacky, relying on internal backbone variables, but it's the only way to get this knowledge
                    // this is covered by unit tests so if the variable ever changes, we'll be alerted to it
                    if (PubSub._events['ugc:user:statuschange']) {
                        // someone is listening in for a ugc login event, this triggers the FileMobile login
                        this.getUserInfo();
                    }
                } else {
                    if (loginStatus === 'loggedOut' || loginStatus === 'loginFailed') {
                        this._loginPromise.reject();
                        this.logoutUser();
                    }
                    PubSub.trigger('ugc:user:statuschange', loginStatus);
                }
            },

            /**
             * Gets user information.
             * @returns {Deferred} Returns promise that resolves when done
             */
            getUserInfo: function() {
                var state = this._loginState;
                // we only want to use the loginPromise when we expect it to resolve soon
                // this reduces memory leaks since the loginPromise could stay pending for a long long time
                if (state === 'loggingIn' || state === 'loggedIn' || UserManager.getLoginStatus() === 'loggedIn') {
                    return this._loginPromise.then(_.bind(function(){
                        return CacheManager.getValue('filemobileuserinfo', this._getFilemobileUserInfo);
                    }, this));
                } else {
                    return $.Deferred().reject();
                }
            },


            /**
             * Gets the information for the logged in user account.
             */
            getUserManagerUserData: function() {
                var userAccount = UserManager.getAccount();
                if (userAccount && userAccount.getUserFirstName()) {
                    return {
                        firstname: userAccount.getUserFirstName(),
                        lastname: userAccount.getUserLastName(),
                        avatar: userAccount.getUserAvatar()
                    };
                } else {
                    return {};
                }
            },

            /**
             * Gets core user information.
             * @returns {Deferred} Returns promise that resolves when done
             * @private
             */
            _getCoreUserInfo: function() {
                return UserManager.getCoreUserInfo()
                    .then(_.bind(function(coreUserData) {
                        // merge new core data with existing user manager data
                        return $.extend({}, coreUserData, this.getUserManagerUserData());
                    }, this),
                    function() {
                        console.warn('failed to get user core info!');
                    });
            },

            /**
             * Gets Filemobile session data for a user.
             * @returns {Deferred} Returns a promise that resolves with the filemobile user data when completed
             * @private
             */
            _getFilemobileUserInfo: function() {
                return this._getCoreUserInfo()
                    .then(function(mergedUserInfo) {
                        return StateManager.fetchData('/filemobile/getfmsession/', {
                            type: 'POST',
                            data: {coreuserid: mergedUserInfo.CoreUserId, atyponsessiontoken: mergedUserInfo.AtyponSessionKey}
                        }).then(function (rd) {
                                if (rd.success.status.state === 'valid') {
                                    var resp = rd.success.response;
                                    mergedUserInfo.sessiontoken = resp.FileMobileSessionToken;
                                    mergedUserInfo.fmid = resp.FileMobileId;
                                    return mergedUserInfo;
                                } else {
                                    console.warn('unable to validate filemobile user!');
                                    return $.Deferred().reject();
                                }
                            }, function () {
                                console.warn('unable to get filemobile user data!');
                            }
                        );
                    }).done(_.bind(function(userInfo) {
                        this._loginState = 'loggedIn';
                        PubSub.trigger('ugc:user:statuschange', this._loginState, userInfo);
                    }, this)).fail(_.bind(function() {
                        this._loginState = 'loginFailed';
                        PubSub.trigger('ugc:user:statuschange', this._loginState);
                    }, this));
            },

            /**
             * Gets user's logged in state.
             * @returns {String} returns 'loggedIn', 'loggingIn', 'loginFailed' or 'loggedOut'
             */
            getLoginState: function() {
                return this._loginState;
            },

            /**
             * Logs user out of filemobile and user manager.
             */
            logoutUser: function() {
                CacheManager.clearValue('filemobileuserinfo');
            }

        });

        /**
         * Return page class.
         */
        return new UGCUser();
    });
