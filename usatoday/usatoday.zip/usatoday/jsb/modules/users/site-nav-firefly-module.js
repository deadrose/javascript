
/**
 * @fileoverview User dropdown module (in the top nav).
 * @author erik.kallevig@f-i.com (Erik Kallevig)
 */
 
define('modules/users/site-nav-firefly-module',[
    'jquery',
    'underscore',
    'modules/header/site-nav-dropdown',
    'pubsub',
    'utils',
    'user-manager',
    'user-accounts/firefly-user-account'
],
function(
    $,
    _,
    SiteNavDropdown,
    PubSub,
    Utils,
    UserManager
) {
    'use strict';

    /**
     * View class.
     */
    var FireflyDropdown = SiteNavDropdown.extend({

        initialize: function(options) {
            this.pubSub = {
                'page:load': this.updateRedirectURLs,
                'user:statuschange': this.showLoggedInStatus
            };

            this.$siteNavDropdown = this.$('.site-nav-dropdown');
            this.$navSpan = this.$('.site-nav-firefly-span');
            this.$name = this.$('.site-nav-firefly-user-display-name');

            this.events = _.extend({},SiteNavDropdown.prototype.events,this.events);            
            SiteNavDropdown.prototype.initialize.call(this, options);
        },

        /**
         * Update all SAM URLs on the page with the current page's redirect URL.
         * @param {Event} e event
         */
        updateRedirectURLs: function(e) {
            var onSuccessRedirectURL = Utils.getPageUrl();

            var newQSP = '?onSuccessRedirectURL=' + encodeURIComponent(onSuccessRedirectURL);
            
            $(".sam-returns").each(function(index, link) {
                var $link = $(link);
                var url = $link.attr('href');
                
                if (typeof(url) === 'string') {
                    var splitUrl = url.split(/[\?\&]/);
                    var append = "";

                    // for now assuming first QSP is onSuccessRedirectURL
                    if (splitUrl.length > 2) {
                        append = '&' + splitUrl.slice(2).join('&');
                    }

                    $link.attr('href', splitUrl[0] + newQSP + append);
                }
            });
        },

        showLoggedInStatus: function(accountName, loginStatus, userData) {
            if (accountName !== 'firefly') {
                return;
            }
            if (this.$navSpan) {
                this.$navSpan.addClass('loaded');
                // delete this.$navSpan;           
            }
            if (loginStatus === 'loggedIn') {
                this.showLoggedInUser(userData);
            } else if (loginStatus !== 'loggingIn') {
                this.showLoggedOutUser();
            }
        },

        /**
         * Shows the user header nav item in the logged out state.
         */
        showLoggedOutUser: function() {
            this.$siteNavDropdown.removeClass('authenticated');
            this.$siteNavDropdown.removeClass('subscribed');
            this.$name.html('');
        },

        /**
         * Shows the user header nav item in the logged in state.
         */
        showLoggedInUser: function(userInfo) {
            var userAccount = UserManager.getAccount('firefly');
            this.$siteNavDropdown.addClass('authenticated');
            if (userInfo.hasMarketAccess) {
                this.$siteNavDropdown.addClass('subscribed');
            }
            
            this.$name.html(userAccount.getUserFirstName() + ' ' + userAccount.getUserLastName());
        }
    });

    return FireflyDropdown;

});
