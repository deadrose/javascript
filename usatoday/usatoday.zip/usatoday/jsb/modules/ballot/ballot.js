
/**
 * @fileoverview Ballot module functionality.
 * @author Erik Kallevig <ekallevig@gannett.com>
 */
define('modules/ballot/ballot',[
    'jquery',
    'underscore',
    'pubsub',
    'baseview'
],
function(
    $,
    _,
    PubSub,
    BaseView
) {
    "use strict";

var Ballot = BaseView.extend({

    events: {
        'click .submit-answers' : 'onSubmitBallot',
        'click .ballot-answer' : 'selectAnswer'
    },

    initialize: function() {
        BaseView.prototype.initialize.call(this);
        _.bindAll(this, 'onSubmitBallot', 'onCompleteSubmit');
        this.$ballotForm = this.$('.ballot-form');
        this.hasSubmitted = false;
    },

    onSubmitBallot: function(e) {
        if (!this.answerSelected) {
            this.setError('Please select an answer before submitting.');
            return;
        }
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: this.$ballotForm.attr('action'),
            data: this.$ballotForm.serializeArray(),
            timeout: 1000,
            complete: this.onCompleteSubmit
        });
        this.$('.ballot-ts-results').show();
        this.$('.ballot-submit-wrap').hide();
        this.hasSubmitted = true;        
        // Track the ballot submission
        PubSub.trigger('uotrack', 'ballotsubmitted');
    },

    setError: function(errorText) {
        this.$('.ballot-error').show().text(errorText);
    },

    hideError: function() {
        this.$('.ballot-error').hide();
    },

    onCompleteSubmit: function(e) {
    },

    selectAnswer: function(e) {
        this.answerSelected = true;
        this.hideError();
        if (this.hasSubmitted || this.$ballotForm.data('disabled')) return;
        var $li = $(e.currentTarget);
        var selectedKey = $li.data('key');

        // Select the hidden radio
        var $radio = $li.find('.ballot-answer-input');
        $radio.prop('checked', true);

        // Remove inactive class from selected item and add inactive to others.
        var $list = $li.parents('ul').eq(0);
        var $lis = $list.find('li');
        $lis.each(function(i, el) {
            var $iterLi = $(el);
            if (selectedKey != $(el).data('key')) {
                $iterLi.addClass('inactive').removeClass('selected');
            } else {
                $li.removeClass('inactive').addClass('selected');
            }
        });

        // Track the answer selection
        PubSub.trigger('uotrack', 'ballotanswerselected');

        this.$('.submit-answers').removeClass('disabled');

    },

    destroy: function(removeEl) {
        BaseView.prototype.destroy.call(this, removeEl);
    }
});

/**
 * Return page class.
 */
return Ballot;

});
