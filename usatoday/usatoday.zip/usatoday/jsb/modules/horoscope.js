
/**
 * @fileoverview Horoscope view module.
 * @author mbriede@gannett.com (Matthew Briede)
 */
define('modules/horoscope',[
    'jquery',
    'underscore',
    'baseview',
    'state',
    'utils',
    'form/base-form',
    'form/dropdown'
],
    function(
        $,
        _,
        BaseView,
        StateManager,
        Utils,
        FormView,
        Dropdown
        ) {
        "use strict";
        /**
         * View class.
         */

        var HoroscopeModule = BaseView.extend({

            // View element.
            el: '.horoscope-primary-wrapper',

            /**
             * Initialize view.
             * @param {Object} options
             */
            initialize: function(options) {

                _.bindAll(this, 'monthSelect', 'daySelect');
                BaseView.prototype.initialize.call(this, options);

                this.$horoscopeForm = this.$('.horoscope-form');
                this.dropdownMonth = this.$('#horoscope-month-select');
                this.dropdownDay = this.$('#horoscope-day-select');

                this.selectedMonth = 0;
                this.selectedDay = 0;

                this.errorMessage = this.$('.horoscope-error');

                this.dateAmounts = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
                this.horoscopeSigns =
                [
                    {
                        "title": "aries",
                        "range":
                            {
                                "months": [3, 4],
                                "days": [21, 20]
                            }
                    },
                    {
                        "title": "taurus",
                        "range":
                            {
                                "months": [4, 5],
                                "days": [21, 20]
                            }
                    },
                    {
                        "title": "gemini",
                        "range":
                            {
                                "months": [5, 6],
                                "days": [21, 20]
                            }
                    },
                    {
                        "title": "cancer",
                        "range":
                            {
                                "months": [6, 7],
                                "days": [21, 22]
                            }
                    },
                    {
                        "title": "leo",
                        "range":
                            {
                                "months": [7, 8],
                                "days": [23, 23]
                            }
                    },
                    {
                        "title": "virgo",
                        "range":
                            {
                                "months": [8, 9],
                                "days": [24, 22]
                            }
                    },
                    {
                        "title": "libra",
                        "range":
                            {
                                "months": [9, 10],
                                "days": [23, 23]
                            }
                    },
                    {
                        "title": "scorpio",
                        "range":
                            {
                                "months": [10, 11],
                                "days": [24, 22]
                            }
                    },
                    {
                        "title": "sagittarius",
                        "range":
                            {
                                "months": [11, 12],
                                "days": [23, 21]
                            }
                    },
                    {
                        "title": "capricorn",
                        "range":
                            {
                                "months": [12, 1],
                                "days": [22, 19]
                            }
                    },
                    {
                        "title": "aquarius",
                        "range":
                            {
                                "months": [1, 2],
                                "days": [20, 18]
                            }
                    },
                    {
                        "title": "pisces",
                        "range":
                            {
                                "months": [2, 3],
                                "days": [19, 20]
                            }
                    }
                ];

                this._setupForm();
            },

            _setupForm: function() {
                this.subviews.monthDropdown = new Dropdown({
                    el: this.dropdownMonth,
                    onSelect: this.monthSelect
                });

                this.subviews.dayDropdown = new Dropdown({
                    el: this.dropdownDay,
                    onSelect: this.daySelect
                });

                this.$horoscopeForm.submit(_.bind(function(e){
                    e.preventDefault();
                    
                    if((this.selectedMonth !== 0) && (this.selectedDay !== 0)) {
                        if(this.dateAmounts[(this.selectedMonth - 1)] >= this.selectedDay) {
                            this._determineSign(this.selectedMonth, this.selectedDay);
                        } else {
                            this.errorMessage.removeClass('hidden');
                        }
                    } else {
                        this.errorMessage.removeClass('hidden');
                    }
                }, this));
            },

            //Dropdown month select
            monthSelect: function(value, data) {
                this.selectedMonth = value;
            },

            //Dropdown day select
            daySelect: function(value, data) {
                this.selectedDay = value;
            },

            //Select horoscope sign
            _determineSign: function(month, day) {
                var sign;

                $.each(this.horoscopeSigns, function() {
                    if((month == this.range.months[0]  && day >= this.range.days[0]) || (month == this.range.months[1] && day <= this.range.days[1])) {
                        sign = this.title;
                        return false;
                    }
                });
                Utils.triggerRoute('/horoscope/'+ sign + '/');
            }
        });

        /**
         * Return view class.
         */
        return HoroscopeModule;
    }
);