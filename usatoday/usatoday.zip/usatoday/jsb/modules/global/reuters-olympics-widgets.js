
/* global Reuters:true */
/**
 * @fileoverview Reuters Olympics Widgets view
 * @author ikenticus
 */
define('modules/global/reuters-olympics-widgets',[
    'jquery',
    'underscore',
    'baseview'
],
function(
    $,
    _,
    BaseView
)
    {
        var OlympicsWidgetsView = BaseView.extend({

            events: {
                'click .widget-switch-block': 'switchWidget'
            },

            initialize: function(options) {
                $.extend(options, {
                    numberRetries: 12,
                    refreshInterval: 5000
                }, options);


                BaseView.prototype.initialize.call(this, options);

                _.bindAll(this, 'checkWidgetResults');

                this.$widget = this.$('.olympics-primary-widget');
                if (!this.$widget.length) {
                    // if primary not found, it must be a sidebar widget
                    this.$widget = this.$('.olympics-sidebar-widget');
                }
                this.createWidget();
            },

            createWidget: function() {
                var filters = ['athlete', 'country', 'day', 'discipline', 'event'];
                var widget = this.$widget;
                this.$widget.find('.widget-wrapper').each(function() {
                    var wrapper = $(this);
                    var params = {"el": "#" + wrapper.attr('id'), "highlight": "USA" };
                    // loop through the filters and add to params if defined
                    for (var f = 0; f < filters.length; ++f) {
                        if (wrapper.data(filters[f])) {
                            params[filters[f]] = wrapper.data(filters[f]).toString();
                        } else if (widget.data(filters[f])) {
                            params[filters[f]] = widget.data(filters[f]).toString();
                        }
                    }
                    switch($(this).data('widget')) {
                        case 'medals':
                            params.sort = 'total';
                            if (widget.data('country') || widget.data('discipline')) {
                                new Reuters.Olympics.View.MedalTable(params);
                            } else {
                                new Reuters.Olympics.View.MedalCount(params);
                            }
                            break;
                        case 'schedule':
                            new Reuters.Olympics.View.Schedule(params);
                            break;
                        case 'results':
                            new Reuters.Olympics.View.Results(params);
                            break;
                    }
                });

                this.numRetries = this.options.numberRetries;
                this.checkWidgetResults();
            },

            checkWidgetResults: function() {

                // sidebar widget empty results
                this.$('.olympics-sidebar-widget').each(function() {
                    var widget = $(this);
                    var emptyModule = true;
                    var module = widget.closest('.card-sidebar');
                    widget.find('.widget-wrapper').each(function() {
                        var wrapper = $(this);
                        if (wrapper.html().length === 0 || wrapper.html().indexOf('error') > 0 || wrapper.html().indexOf('no results') > 0) {
                            if (!wrapper.hasClass('toggle')) {
                                wrapper.hide(); // do not hide for toggle cases like results widgets
                            }
                        } else {
                            if (!wrapper.hasClass('toggle')) {
                                wrapper.show(); // do not show for toggle cases like results widgets
                            }
                            emptyModule = false;
                        }
                    });
                    if (emptyModule) {
                        module.hide();
                    } else {
                        module.show();
                    }

                    var maxRows = widget.data('max-rows');
                    var maxLabels = widget.data('max-labels');
                    var maxPhases = widget.data('max-phases');

                    if (maxRows) {

                        // limit schedule widget rows displayed
                        $(this).find('.scheduleUnit').each(function(i) {
                            if (i >= maxRows) {
                                $(this).hide();
                            }
                        });

                        // limit results widget rows displayed per table
                        $(this).find('.resultsTable').each(function() {
                            $(this).find('.label').each(function(i) {
                                if (i > maxLabels) {
                                    var emptyRow = $(this).closest('tr');
                                    if (!emptyRow.hasClass('resultRow')) {
                                        emptyRow.hide();
                                    }
                                }
                            });
                            $(this).find('.resultRow').each(function(i) {
                                if (i >= maxRows) {
                                    $(this).hide();
                                }
                            });
                        });

                    }

                });

                // removing the height constraint from Reuters to avoid scrolling
                //this.$('.reutersOlympicsWidget .widgetBody').removeClass('constrainHeight');
                // This seems to break the RIGHT NOW module, so using alternative:
                this.$('.reutersOlympicsWidget .widgetBody.constrainHeight').css('max-height', '450px');

                this.numRetries--;
                if (this.numRetries > 0) {
                    this.widgetTimer = setTimeout(this.checkWidgetResults, this.options.refreshInterval);
                }
            },

            switchWidget: function(e) {
                var buttons = this.$('.widget-switch-block');
                buttons.removeClass('selected');

                var target = $(e.currentTarget);
                target.addClass('selected');

                var index = buttons.index(target);
                this.$('.widget-wrapper').each(function(i) {
                    var widget = $(this);
                    if (i == index) {
                        widget.removeClass('hide');
                    } else if (!widget.hasClass('hide')) {
                        widget.addClass('hide');
                    }
                });
            },

            destroy: function() {
                this.$widget.find('.widget-script-wrapper').empty();
                this.numRetries = 0;
                if (this.widgetTimer) {
                    clearTimeout(this.widgetTimer);
                }
                BaseView.prototype.destroy.call(this);
            }
            
        });

        return OlympicsWidgetsView;
    }
);